import { useState, useEffect } from 'react';
import styled, { keyframes } from 'styled-components';

// Animations
const float = keyframes`
  0% {
    transform: translateY(0) rotate(0deg);
  }
  50% {
    transform: translateY(-10px) rotate(2deg);
  }
  100% {
    transform: translateY(0) rotate(0deg);
  }
`;

const pulse = keyframes`
  0% {
    transform: scale(1);
    opacity: 1;
  }
  50% {
    transform: scale(1.1);
    opacity: 0.8;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
`;

// Styled components
const Container = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 5;
`;

const PixelChar = styled.div<{ delay: string; speed: string; size: string }>`
  position: absolute;
  font-size: ${props => props.size};
  animation: ${float} ${props => props.speed} ease-in-out infinite;
  animation-delay: ${props => props.delay};
  filter: drop-shadow(0 0 5px currentColor);
  transition: transform 0.3s;
  will-change: transform;
  user-select: none;
  
  &:hover {
    animation: ${pulse} 1s ease-in-out infinite;
  }
`;

interface PixelAnimationProps {
  density?: number;
}

interface PixelObject {
  id: number;
  char: string;
  color: string;
  top: string;
  left: string;
  size: string;
  delay: string;
  speed: string;
}

export default function PixelAnimation({ density = 15 }: PixelAnimationProps) {
  const [pixelObjects, setPixelObjects] = useState<PixelObject[]>([]);
  
  useEffect(() => {
    const pixels: PixelObject[] = [];
    const characters = ['👾', '🤖', '👽', '🎮', '💾', '🕹️', '👁️', '🧠', '⚡', '🔮', '💎', '🔌'];
    const colors = ['#ff00ff', '#00ffff', '#ff0000', '#0f0', '#ff00aa', '#aa00ff', '#ffff00'];
    
    for (let i = 0; i < density; i++) {
      pixels.push({
        id: i,
        char: characters[Math.floor(Math.random() * characters.length)],
        color: colors[Math.floor(Math.random() * colors.length)],
        top: `${Math.random() * 100}%`,
        left: `${Math.random() * 100}%`,
        size: `${Math.random() * 20 + 20}px`,
        delay: `${Math.random() * 5}s`,
        speed: `${Math.random() * 8 + 4}s`,
      });
    }
    
    setPixelObjects(pixels);
  }, [density]);
  
  return (
    <Container>
      {pixelObjects.map((obj) => (
        <PixelChar
          key={obj.id}
          delay={obj.delay}
          speed={obj.speed}
          size={obj.size}
          style={{
            top: obj.top,
            left: obj.left,
            color: obj.color,
          }}
        >
          {obj.char}
        </PixelChar>
      ))}
    </Container>
  );
} 