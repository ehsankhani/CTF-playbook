import { useState, useEffect, useRef } from 'react';
import { Howl } from 'howler';
import styled, { keyframes, createGlobalStyle } from 'styled-components';
import PixelAnimation from './components/PixelAnimation';
import HackingTerminal from './components/HackingTerminal';
import BackgroundGlitch from './components/BackgroundGlitch';
import React from 'react';

// Global styles for cyberpunk theme
const GlobalStyle = createGlobalStyle`
  @font-face {
    font-family: 'VCR OSD Mono';
    src: url('https://cdn.jsdelivr.net/npm/vcr-osd-mono@1.0.1/VCR_OSD_MONO_1.001.ttf') format('truetype');
  }

  body {
    margin: 0;
    padding: 0;
    background-color: #0a0a1e;
    font-family: 'VCR OSD Mono', monospace;
    color: #0f0;
    overflow: hidden;
  }
`;

// Animations
const scanline = keyframes`
  0% {
    transform: translateY(0);
  }
  100% {
    transform: translateY(100vh);
  }
`;

const glitch = keyframes`
  0% {
    transform: translate(0);
  }
  20% {
    transform: translate(-2px, 2px);
  }
  40% {
    transform: translate(-2px, -2px);
  }
  60% {
    transform: translate(2px, 2px);
  }
  80% {
    transform: translate(2px, -2px);
  }
  100% {
    transform: translate(0);
  }
`;

const flicker = keyframes`
  0% {
    opacity: 1;
  }
  10% {
    opacity: 0.8;
  }
  20% {
    opacity: 1;
  }
  30% {
    opacity: 0.6;
  }
  40% {
    opacity: 1;
  }
  50% {
    opacity: 0.9;
  }
  60% {
    opacity: 1;
  }
  70% {
    opacity: 0.7;
  }
  80% {
    opacity: 1;
  }
  90% {
    opacity: 0.8;
  }
  100% {
    opacity: 1;
  }
`;

const float = keyframes`
  0% {
    transform: translateY(0) rotate(0deg);
  }
  50% {
    transform: translateY(-10px) rotate(2deg);
  }
  100% {
    transform: translateY(0) rotate(0deg);
  }
`;

// Styled components
const CyberpunkContainer = styled.div`
  min-height: 100vh;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: relative;
  background: linear-gradient(to bottom, #0a0a1e, #1a0a2e);
  overflow: hidden;
  padding: 20px;
  
  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: repeating-linear-gradient(
      to bottom,
      transparent 0%,
      rgba(10, 10, 30, 0.1) 1px,
      transparent 2px
    );
    pointer-events: none;
    animation: ${scanline} 8s linear infinite;
  }
  
  &::after {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(
      circle at center,
      transparent 0%,
      rgba(10, 10, 30, 0.8) 80%,
      rgba(10, 10, 30, 0.95) 100%
    );
    pointer-events: none;
  }
`;

const GlitchButton = styled.button`
  background: linear-gradient(45deg, #ff00ff, #00ffff);
  border: 3px solid #00ffff;
  color: #fff;
  font-family: 'VCR OSD Mono', monospace;
  font-size: 24px;
  padding: 12px 24px;
  margin: 20px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  text-shadow: 2px 2px #ff00ff;
  animation: ${flicker} 3s infinite, ${float} 6s ease-in-out infinite;
  transition: all 0.3s;
  z-index: 10;
  box-shadow: 0 0 15px #00ffff, 0 0 25px #00ffff;
  text-transform: uppercase;
  letter-spacing: 2px;
  
  &:hover {
    animation: ${glitch} 0.3s infinite, ${flicker} 2s infinite;
    background: linear-gradient(45deg, #00ffff, #ff00ff);
    transform: scale(1.05);
    box-shadow: 0 0 25px #00ffff, 0 0 35px #ff00ff;
  }
  
  &::before {
    content: "";
    position: absolute;
    top: -10px;
    left: -10px;
    right: -10px;
    bottom: -10px;
    border: 2px solid #ff00ff;
    pointer-events: none;
    animation: ${glitch} 3s infinite alternate;
  }
`;

const HackButton = styled(GlitchButton)`
  background: linear-gradient(45deg, #00ff00, #00ffff);
  border: 3px solid #00ff00;
  margin-top: 20px;
  
  &:hover {
    background: linear-gradient(45deg, #00ffff, #00ff00);
    box-shadow: 0 0 25px #00ff00, 0 0 35px #00ffff;
  }
  
  &::before {
    border: 2px solid #00ff00;
  }
`;

const GridOverlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: 
    linear-gradient(to right, rgba(0, 255, 255, 0.1) 1px, transparent 1px),
    linear-gradient(to bottom, rgba(0, 255, 255, 0.1) 1px, transparent 1px);
  background-size: 40px 40px;
  pointer-events: none;
  z-index: 1;
`;

const CyberpunkModal = styled.div`
  position: fixed;
  inset: 0;
  z-index: 100;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.85);
`;

const ModalContent = styled.div`
  background: #0a0a1e;
  border: 3px solid #ff00ff;
  box-shadow: 0 0 20px #00ffff, 0 0 30px #ff00ff;
  max-width: 800px;
  width: 100%;
  padding: 30px;
  position: relative;
  overflow-y: auto;
  max-height: 90vh;
  color: #0f0;
  font-size: 18px;
  line-height: 1.6;
  
  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: repeating-linear-gradient(
      to bottom,
      transparent 0%,
      rgba(0, 255, 0, 0.03) 1px,
      transparent 2px
    );
    pointer-events: none;
  }
`;

const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  border-bottom: 2px solid #00ffff;
  padding-bottom: 10px;
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  color: #ff00ff;
  font-size: 32px;
  cursor: pointer;
  font-family: 'VCR OSD Mono', monospace;
  text-shadow: 0 0 5px currentColor;
  
  &:hover {
    color: #00ffff;
    animation: ${glitch} 0.3s infinite;
  }
`;

const ModalTitle = styled.h2`
  color: #00ffff;
  font-size: 28px;
  margin: 0;
  text-shadow: 0 0 5px currentColor;
  animation: ${flicker} 3s infinite;
`;

const Paragraph = styled.p`
  margin-bottom: 16px;
  line-height: 1.6;
  text-shadow: 0 0 2px currentColor;
  
  &:nth-child(odd) {
    color: #0f0;
  }
  
  &:nth-child(even) {
    color: #0ff;
  }
`;

const AudioButton = styled.button`
  position: fixed;
  bottom: 20px;
  right: 20px;
  background: transparent;
  border: 2px solid #00ffff;
  color: #00ffff;
  font-family: 'VCR OSD Mono', monospace;
  padding: 10px;
  cursor: pointer;
  z-index: 50;
  font-size: 16px;
  display: flex;
  align-items: center;
  gap: 5px;
  text-shadow: 0 0 5px currentColor;
  box-shadow: 0 0 10px #00ffff;
  
  &:hover {
    background: rgba(0, 255, 255, 0.2);
  }
`;

const ButtonContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
  z-index: 10;
`;

const BlurOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: 2000;
  backdrop-filter: blur(16px) brightness(0.5);
  background: rgba(0,0,0,0.5);
`;

const ReadyModal = styled.div`
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(20, 0, 40, 0.95);
  border: 3px solid #ff00ff;
  box-shadow: 0 0 30px #00ffff, 0 0 40px #ff00ff;
  border-radius: 18px;
  z-index: 3000;
  padding: 48px 36px 36px 36px;
  text-align: center;
  min-width: 320px;
`;

const ReadyTitle = styled.h1`
  color: #00ffff;
  font-size: 2.2rem;
  margin-bottom: 24px;
  font-family: 'VCR OSD Mono', monospace;
  text-shadow: 0 0 8px #ff00ff;
`;

const ModalButton = styled.button`
  background: linear-gradient(45deg, #ff00ff, #00ffff);
  border: 2px solid #00ffff;
  color: #fff;
  font-family: 'VCR OSD Mono', monospace;
  font-size: 1.2rem;
  padding: 12px 32px;
  margin: 0 18px;
  cursor: pointer;
  border-radius: 8px;
  box-shadow: 0 0 10px #00ffff, 0 0 20px #ff00ff;
  text-transform: uppercase;
  letter-spacing: 2px;
  transition: all 0.2s;
  &:hover {
    background: linear-gradient(45deg, #00ffff, #ff00ff);
    color: #ff00ff;
    border-color: #ff00ff;
  }
`;

const MovingButtonContainer = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 10;
`;

const MovingButton = styled.div<{ top: number; left: number }>`
  position: absolute;
  transition: top 0.7s cubic-bezier(0.4, 2, 0.6, 1), left 0.7s cubic-bezier(0.4, 2, 0.6, 1);
  top: ${props => props.top}%;
  left: ${props => props.left}%;
  pointer-events: auto;
`;

export default function InterestingFacts() {
  const [isOpen, setIsOpen] = useState(false);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [isAudioLoaded, setIsAudioLoaded] = useState(false);
  const [isTerminalOpen, setIsTerminalOpen] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const audioRef = useRef<Howl | null>(null);
  const [button1Pos, setButton1Pos] = useState({ top: 30, left: 30 });
  const [button2Pos, setButton2Pos] = useState({ top: 60, left: 60 });
  
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Howl({
        src: ['/background.mp3'],
        loop: true,
        volume: 0.5,
        autoplay: false,
        onload: () => {
          setIsAudioLoaded(true);
        }
      });
    }
    return () => {
      if (audioRef.current) {
        audioRef.current.stop();
      }
    };
  }, []);
  
  // Play audio and mark as ready
  const handleReady = () => {
    setIsReady(true);
    if (audioRef.current && !audioRef.current.playing()) {
      audioRef.current.play();
      setIsAudioPlaying(true);
    }
  };

  // Quit tab
  const handleQuit = () => {
    window.open('', '_self');
    window.close();
    // If window.close() fails (browser blocks), redirect to about:blank
    setTimeout(() => {
      window.location.href = 'about:blank';
    }, 200);
  };

  // Toggle audio
  const toggleAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (audioRef.current) {
      if (audioRef.current.playing()) {
        audioRef.current.pause();
        setIsAudioPlaying(false);
      } else {
        audioRef.current.play();
        setIsAudioPlaying(true);
      }
    }
  };

  const forcePlayAudio = () => {
    if (audioRef.current && !audioRef.current.playing()) {
      audioRef.current.play();
      setIsAudioPlaying(true);
    }
  };

  useEffect(() => {
    // If not ready, don't attach unlock listeners
    if (!isReady) return;
    // If audio is not playing after ready, attach click/touch listeners
    if (!isAudioPlaying && isAudioLoaded) {
      const unlockAudio = () => {
        if (audioRef.current && !audioRef.current.playing()) {
          audioRef.current.play();
          setIsAudioPlaying(true);
          document.removeEventListener('click', unlockAudio);
          document.removeEventListener('touchstart', unlockAudio);
        }
      };
      document.addEventListener('click', unlockAudio);
      document.addEventListener('touchstart', unlockAudio);
      return () => {
        document.removeEventListener('click', unlockAudio);
        document.removeEventListener('touchstart', unlockAudio);
      };
    }
  }, [isAudioLoaded, isAudioPlaying, isReady]);

  // Move buttons randomly every 1.2s
  useEffect(() => {
    if (!isReady) return;
    const moveButtons = () => {
      // Ensure buttons don't overlap and stay in bounds (10% to 80%)
      let new1, new2;
      do {
        new1 = {
          top: 10 + Math.random() * 70,
          left: 10 + Math.random() * 70,
        };
        new2 = {
          top: 10 + Math.random() * 70,
          left: 10 + Math.random() * 70,
        };
      } while (
        Math.abs(new1.top - new2.top) < 18 && Math.abs(new1.left - new2.left) < 18
      );
      setButton1Pos(new1);
      setButton2Pos(new2);
    };
    moveButtons();
    const interval = setInterval(moveButtons, 1200);
    return () => clearInterval(interval);
  }, [isReady]);

  return (
    <>
      <GlobalStyle />
      {!isReady && (
        <>
          <BlurOverlay />
          <ReadyModal>
            <ReadyTitle>Are you ready??????</ReadyTitle>
            <div style={{ marginBottom: 32, color: '#fff', fontSize: '1.1rem' }}>
              This experience is best with sound ON.<br />
              <span style={{ color: '#ff00ff' }}>Click YES to begin your cyberpunk journey.</span>
            </div>
            <ModalButton onClick={handleReady}>YES</ModalButton>
            <ModalButton onClick={handleQuit}>NO</ModalButton>
          </ReadyModal>
        </>
      )}
      <BackgroundGlitch />
      <CyberpunkContainer style={{ filter: !isReady ? 'blur(16px) brightness(0.5)' : 'none', position: 'relative' }}>
        <GridOverlay />
        <PixelAnimation density={25} />
        <MovingButtonContainer>
          <MovingButton top={button1Pos.top} left={button1Pos.left}>
            <GlitchButton onClick={() => setIsOpen(true)}>
              خواندنی جالب راجب وب
            </GlitchButton>
          </MovingButton>
          <MovingButton top={button2Pos.top} left={button2Pos.left}>
            <HackButton onClick={() => setIsTerminalOpen(true)}>
              Start CTF Terminal :)
            </HackButton>
          </MovingButton>
        </MovingButtonContainer>
        <AudioButton onClick={toggleAudio}>
          {isAudioPlaying ? '🔇 Stop I\'ll Do It' : '🔊 Play I\'ll Do It'}
        </AudioButton>
        {isOpen && (
          <CyberpunkModal>
            <ModalContent>
              <ModalHeader>
                <ModalTitle>Modern Frontend Engineering Insights</ModalTitle>
                <CloseButton onClick={() => setIsOpen(false)}>×</CloseButton>
              </ModalHeader>
              <div>
                <Paragraph>
                  In the early days of web development, the focus was mostly on functionality. But things changed rapidly with the introduction of CSS2 in 1998, which brought visual control to the table. Back then, fixed-width layouts were the norm — a glorious 960px container and a bunch of float hacks.
                </Paragraph>
                <Paragraph>
                  JavaScript didn't even support modules natively until ES6 in 2015. Before that, people either used CommonJS or resorted to IIFE patterns. Fast forward to now, developers work with 3 major frameworks: React, Vue, and Angular — each with its own ecosystem of 700+ packages. It's not uncommon for a single project to have 1284 dependencies installed.
                </Paragraph>
                <Paragraph>
                  One interesting thing is how browser engines handle rendering. Chrome uses Blink, while Firefox relies on Quantum. Their rendering pipelines differ, but both parse and paint the DOM in under 68ms in most cases — a feat considering how complex pages have become.
                </Paragraph>
                <Paragraph>
                  Web performance is an ongoing battle. Lazy loading images, prefetching routes, and code-splitting all aim to reduce load times. The First Contentful Paint ideally happens under 61ms in fast environments. Achieving that requires proper caching, server-side rendering, and maybe even some edge computing.
                </Paragraph>
                <Paragraph>
                  And then there's accessibility (a11y). You'd be surprised how many sites forget to add aria-labels or semantic tags. Developers often leave contrast ratios at 74%, when minimum recommended is 90%. Tools like Axe and Lighthouse help catch those issues, but only if used consistently.
                </Paragraph>
                <Paragraph>
                  One subtle pitfall is time zones. Working with Date() is a nightmare across regions. More than once, a user in UTC+5 received a time-stamped email labeled 13:68 — completely invalid but allowed by a poorly tested regex.
                </Paragraph>
                <Paragraph>
                  Animation timing matters too. requestAnimationFrame() runs at 60fps, and most transitions look smooth at durations between 250ms to 400ms. Still, some designers insist on adding delays like 61ms, 64ms, or 69ms just for aesthetic rhythm.
                </Paragraph>
                <Paragraph>
                  Speaking of odd preferences, CSS units can be controversial. Some swear by em, others by rem. A few still use px for precision. One dev hardcoded font sizes like 13.74px (what?). The debate continues.
                </Paragraph>
                <Paragraph>
                  Finally, don't forget about versioning hell. You might be on React 18.2, but a sub-dependency requires 17.x, leading to 404, 403, or even 422 errors that make no sense. That's modern frontend: flexible, fast, but frustrating.
                </Paragraph>
              </div>
            </ModalContent>
          </CyberpunkModal>
        )}
        <HackingTerminal 
          isVisible={isTerminalOpen} 
          onClose={() => setIsTerminalOpen(false)} 
        />
      </CyberpunkContainer>
    </>
  );
}
