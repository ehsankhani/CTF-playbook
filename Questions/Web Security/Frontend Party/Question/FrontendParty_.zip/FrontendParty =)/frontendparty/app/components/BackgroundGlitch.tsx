import { useEffect, useRef } from 'react';
import styled, { keyframes } from 'styled-components';

const glitchEffect = keyframes`
  0% {
    transform: translate(0);
    opacity: 0.75;
  }
  20% {
    transform: translate(-10px, 10px);
    opacity: 0.85;
  }
  40% {
    transform: translate(-10px, -10px);
    opacity: 0.9;
  }
  60% {
    transform: translate(10px, 10px);
    opacity: 0.8;
  }
  80% {
    transform: translate(10px, -10px);
    opacity: 0.7;
  }
  100% {
    transform: translate(0);
    opacity: 0.75;
  }
`;

const colorShift = keyframes`
  0% { filter: hue-rotate(0deg); }
  25% { filter: hue-rotate(90deg); }
  50% { filter: hue-rotate(180deg); }
  75% { filter: hue-rotate(270deg); }
  100% { filter: hue-rotate(360deg); }
`;

const Container = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  pointer-events: none;
  z-index: 0;
`;

const GlitchCanvas = styled.canvas`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0.1;
  mix-blend-mode: screen;
  animation: ${colorShift} 30s infinite linear;
`;

const GlitchLayer = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: radial-gradient(circle at center, rgba(255, 0, 255, 0.2), transparent 70%);
  animation: ${glitchEffect} 10s infinite alternate;
  pointer-events: none;
  mix-blend-mode: screen;
`;

export default function BackgroundGlitch() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas size to match window
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    // Glitch effect animation
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Draw noise
      const imageData = ctx.createImageData(canvas.width, canvas.height);
      const data = imageData.data;
      
      for (let i = 0; i < data.length; i += 4) {
        // Random static with emphasizing cyberpunk colors
        const r = Math.floor(Math.random() * 255);
        const g = Math.floor(Math.random() * 255);
        const b = Math.floor(Math.random() * 255);
        
        // Bias toward purples, blues, and neons
        data[i] = r > 200 ? 255 : r < 50 ? 0 : r;     // Red
        data[i + 1] = g > 200 ? 255 : g < 50 ? 0 : g; // Green
        data[i + 2] = b > 150 ? 255 : b < 100 ? 100 : b; // Bluish bias
        data[i + 3] = Math.random() > 0.95 ? 255 : 0;  // Alpha - sparse points
      }
      
      ctx.putImageData(imageData, 0, 0);
      
      // Draw horizontal lines
      if (Math.random() > 0.95) {
        const y = Math.random() * canvas.height;
        const height = Math.random() * 2 + 1;
        
        ctx.fillStyle = 'rgba(0, 255, 255, 0.5)';
        ctx.fillRect(0, y, canvas.width, height);
      }
      
      // Draw vertical lines
      if (Math.random() > 0.97) {
        const x = Math.random() * canvas.width;
        const width = Math.random() * 2 + 1;
        
        ctx.fillStyle = 'rgba(255, 0, 255, 0.5)';
        ctx.fillRect(x, 0, width, canvas.height);
      }
      
      // Occasionally add blocks of glitch
      if (Math.random() > 0.997) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const width = Math.random() * 100 + 50;
        const height = Math.random() * 100 + 30;
        
        ctx.fillStyle = 'rgba(0, 255, 150, 0.3)';
        ctx.fillRect(x, y, width, height);
      }
      
      animationRef.current = requestAnimationFrame(draw);
    };
    
    draw();
    
    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);
  
  return (
    <Container>
      <GlitchCanvas ref={canvasRef} />
      <GlitchLayer />
    </Container>
  );
} 