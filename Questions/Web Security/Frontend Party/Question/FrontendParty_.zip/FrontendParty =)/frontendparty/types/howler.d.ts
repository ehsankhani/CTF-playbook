declare module 'howler' {
  export class Howl {
    constructor(options: {
      src: string[];
      autoplay?: boolean;
      loop?: boolean;
      volume?: number;
      html5?: boolean;
      rate?: number;
      onend?: () => void;
      onload?: () => void;
      onloaderror?: (id: number, error: any) => void;
      onplay?: () => void;
      onpause?: () => void;
      onstop?: () => void;
      onmute?: () => void;
      onvolume?: () => void;
      onrate?: () => void;
      onseek?: () => void;
      onfade?: () => void;
    });
    play(spriteOrId?: string | number): number;
    pause(id?: number): this;
    stop(id?: number): this;
    mute(muted?: boolean, id?: number): this;
    volume(volume?: number, id?: number): this | number;
    fade(from: number, to: number, duration: number, id?: number): this;
    rate(rate?: number, id?: number): this | number;
    seek(seek?: number, id?: number): this | number;
    loop(loop?: boolean, id?: number): this | boolean;
    state(): 'unloaded' | 'loading' | 'loaded';
    playing(id?: number): boolean;
    duration(id?: number): number;
    on(event: string, callback: Function, id?: number): this;
    once(event: string, callback: Function, id?: number): this;
    off(event: string, callback?: Function, id?: number): this;
    load(): this;
    unload(): void;
  }

  export class Sound {
    constructor(howl: Howl);
  }

  export const Howler: {
    mute(muted: boolean): void;
    volume(volume?: number): number | void;
    codecs(ext: string): boolean;
    unload(): void;
    usingWebAudio: boolean;
    noAudio: boolean;
    autoUnlock: boolean;
    autoSuspend: boolean;
    ctx: AudioContext;
    masterGain: GainNode;
  };
} 