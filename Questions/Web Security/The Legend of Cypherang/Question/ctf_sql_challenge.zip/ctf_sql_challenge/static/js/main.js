document.addEventListener('DOMContentLoaded', function() {
    // Create floating particles
    createFloatingParticles();
    
    // Add code matrix rain effect
    createCodeRain();
    
    // Add cyber decorations and animations
    animateCyberElements();
    
    // Easter egg: Konami code reveals a hint
    setupKonamiCode();
});

// Create floating particles in the background
function createFloatingParticles() {
    const particlesContainer = document.querySelector('.floating-particles');
    if (!particlesContainer) return;
    
    for (let i = 0; i < 50; i++) {
        const particle = document.createElement('div');
        particle.classList.add('particle');
        
        // Random position, size and animation delay
        const size = Math.random() * 5 + 1;
        const posX = Math.random() * 100;
        const posY = Math.random() * 100;
        const delay = Math.random() * 5;
        
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        particle.style.left = `${posX}%`;
        particle.style.top = `${posY}%`;
        particle.style.animationDelay = `${delay}s`;
        
        particlesContainer.appendChild(particle);
    }
    
    // Add styles for particles
    const style = document.createElement('style');
    style.textContent = `
        .particle {
            position: absolute;
            background-color: rgba(79, 70, 229, 0.7);
            border-radius: 50%;
            box-shadow: 0 0 10px rgba(79, 70, 229, 0.5);
            pointer-events: none;
            animation: float 15s linear infinite;
        }
        
        @keyframes float {
            0% {
                transform: translateY(0) rotate(0deg);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100vh) rotate(360deg);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
}

// Create Matrix-like code rain in the footer
function createCodeRain() {
    const codeRainContainer = document.querySelector('.code-rain');
    if (!codeRainContainer) return;
    
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<>/\\:;"\'[]{}=+-_)(*&^%$#@!~`|';
    const columns = Math.floor(codeRainContainer.offsetWidth / 15);
    
    for (let i = 0; i < columns; i++) {
        const column = document.createElement('div');
        column.classList.add('code-column');
        
        const charCount = 5 + Math.floor(Math.random() * 10);
        const delay = Math.random() * 2;
        
        for (let j = 0; j < charCount; j++) {
            const char = document.createElement('div');
            char.classList.add('code-char');
            char.textContent = characters.charAt(Math.floor(Math.random() * characters.length));
            
            const charDelay = delay + (j * 0.1);
            char.style.animationDelay = `${charDelay}s`;
            
            column.appendChild(char);
        }
        
        codeRainContainer.appendChild(column);
    }
    
    // Add styles for code rain
    const style = document.createElement('style');
    style.textContent = `
        .code-rain {
            display: flex;
            justify-content: space-around;
            height: 40px;
            overflow: hidden;
            margin-top: 10px;
        }
        
        .code-column {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .code-char {
            color: #4f46e5;
            font-size: 0.8rem;
            font-family: monospace;
            animation: rain 2s linear infinite;
            opacity: 0;
        }
        
        @keyframes rain {
            0% {
                transform: translateY(-20px);
                opacity: 0;
            }
            50% {
                opacity: 1;
            }
            100% {
                transform: translateY(20px);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
}

// Animate cyber elements
function animateCyberElements() {
    // Cyber hexagon animation
    const hexagon = document.querySelector('.cyber-hexagon');
    if (hexagon) {
        const style = document.createElement('style');
        style.textContent = `
            .cyber-hexagon {
                position: absolute;
                width: 100px;
                height: 60px;
                background-color: rgba(79, 70, 229, 0.1);
                top: 50%;
                left: 10%;
                transform: translateY(-50%);
                clip-path: polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%);
                animation: rotate-hex 10s linear infinite, pulse-glow 3s ease-in-out infinite;
            }
            
            @keyframes rotate-hex {
                0% {
                    transform: translateY(-50%) rotate(0deg);
                }
                100% {
                    transform: translateY(-50%) rotate(360deg);
                }
            }
            
            @keyframes pulse-glow {
                0%, 100% {
                    box-shadow: 0 0 10px rgba(79, 70, 229, 0.3);
                }
                50% {
                    box-shadow: 0 0 20px rgba(79, 70, 229, 0.6);
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Cyber circle animation
    const circle = document.querySelector('.cyber-circle');
    if (circle) {
        const style = document.createElement('style');
        style.textContent = `
            .cyber-circle {
                position: absolute;
                width: 60px;
                height: 60px;
                border-radius: 50%;
                border: 2px solid rgba(79, 70, 229, 0.3);
                top: 50%;
                right: 10%;
                transform: translateY(-50%);
                animation: pulse-border 3s ease-in-out infinite;
            }
            
            .cyber-circle::before, .cyber-circle::after {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                width: 100%;
                height: 100%;
                border-radius: 50%;
                border: 2px solid rgba(79, 70, 229, 0.15);
                transform: translate(-50%, -50%);
            }
            
            .cyber-circle::before {
                animation: ripple 3s linear infinite;
            }
            
            .cyber-circle::after {
                animation: ripple 3s linear 1.5s infinite;
            }
            
            @keyframes pulse-border {
                0%, 100% {
                    box-shadow: 0 0 0 0 rgba(79, 70, 229, 0.4);
                }
                50% {
                    box-shadow: 0 0 0 10px rgba(79, 70, 229, 0);
                }
            }
            
            @keyframes ripple {
                0% {
                    width: 100%;
                    height: 100%;
                    opacity: 1;
                }
                100% {
                    width: 200%;
                    height: 200%;
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Scanner beam animation
    const scanner = document.querySelector('.cyber-scanner');
    if (scanner) {
        const style = document.createElement('style');
        style.textContent = `
            .cyber-scanner {
                position: relative;
                width: 100%;
                height: 200px;
                background-color: rgba(0, 0, 0, 0.2);
                border-radius: 8px;
                overflow: hidden;
            }
            
            .scanner-beam {
                position: absolute;
                width: 100%;
                height: 2px;
                background: linear-gradient(90deg, transparent, #4f46e5, transparent);
                top: 0;
                left: 0;
                animation: scan 3s ease-in-out infinite;
                box-shadow: 0 0 10px rgba(79, 70, 229, 0.7);
            }
            
            @keyframes scan {
                0%, 100% {
                    top: 0;
                }
                50% {
                    top: 100%;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Rotating cube animation
    const cube = document.querySelector('.rotating-cube');
    if (cube) {
        cube.innerHTML = `
            <div class="cube">
                <div class="cube-face front"></div>
                <div class="cube-face back"></div>
                <div class="cube-face right"></div>
                <div class="cube-face left"></div>
                <div class="cube-face top"></div>
                <div class="cube-face bottom"></div>
            </div>
        `;
        
        const style = document.createElement('style');
        style.textContent = `
            .rotating-cube {
                perspective: 600px;
                width: 100px;
                height: 100px;
                margin: 1rem auto;
            }
            
            .cube {
                width: 100%;
                height: 100%;
                position: relative;
                transform-style: preserve-3d;
                animation: rotate-cube 15s infinite linear;
            }
            
            .cube-face {
                position: absolute;
                width: 100%;
                height: 100%;
                background-color: rgba(79, 70, 229, 0.2);
                border: 1px solid rgba(79, 70, 229, 0.5);
                opacity: 0.7;
            }
            
            .front  { transform: rotateY(0deg) translateZ(50px); }
            .back   { transform: rotateY(180deg) translateZ(50px); }
            .right  { transform: rotateY(90deg) translateZ(50px); }
            .left   { transform: rotateY(-90deg) translateZ(50px); }
            .top    { transform: rotateX(90deg) translateZ(50px); }
            .bottom { transform: rotateX(-90deg) translateZ(50px); }
            
            @keyframes rotate-cube {
                0% { transform: rotateX(0deg) rotateY(0deg); }
                100% { transform: rotateX(360deg) rotateY(360deg); }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Security scan animation
    const securityScan = document.querySelector('.security-scan');
    if (securityScan) {
        const style = document.createElement('style');
        style.textContent = `
            .security-scan {
                position: relative;
                width: 100%;
                height: 4px;
                background-color: rgba(255, 255, 255, 0.1);
                margin: 1rem 0;
                overflow: hidden;
            }
            
            .security-scan::before {
                content: '';
                position: absolute;
                width: 50%;
                height: 100%;
                background: linear-gradient(90deg, transparent, #4f46e5, transparent);
                animation: security-scan 2s ease-in-out infinite;
            }
            
            @keyframes security-scan {
                0%, 100% {
                    left: -50%;
                }
                50% {
                    left: 100%;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Fake terminal animations
    const terminals = document.querySelectorAll('.fake-terminal');
    if (terminals.length > 0) {
        const style = document.createElement('style');
        style.textContent = `
            .fake-terminal {
                background-color: rgba(0, 0, 0, 0.5);
                border-radius: 4px;
                border: 1px solid #4f46e5;
                overflow: hidden;
                margin-top: 1rem;
                font-family: monospace;
            }
            
            .terminal-header {
                background-color: rgba(79, 70, 229, 0.3);
                padding: 0.5rem;
                text-align: center;
                font-weight: bold;
            }
            
            .terminal-body {
                padding: 1rem;
            }
            
            .terminal-body p {
                margin-bottom: 0.5rem;
                position: relative;
                overflow: hidden;
                animation: type 2s steps(60, end);
                white-space: nowrap;
            }
            
            @keyframes type {
                from { width: 0; }
                to { width: 100%; }
            }
        `;
        document.head.appendChild(style);
        
        // Add delayed typing effect to terminal lines
        terminals.forEach(terminal => {
            const lines = terminal.querySelectorAll('.terminal-body p');
            lines.forEach((line, index) => {
                line.style.animationDelay = `${index * 0.5}s`;
            });
        });
    }
}

// Konami code Easter egg (up, up, down, down, left, right, left, right, B, A)
function setupKonamiCode() {
    const konamiCode = [38, 38, 40, 40, 37, 39, 37, 39, 66, 65];
    let konamiIndex = 0;
    
    document.addEventListener('keydown', function(e) {
        if (e.keyCode === konamiCode[konamiIndex]) {
            konamiIndex++;
            
            if (konamiIndex === konamiCode.length) {
                revealHint();
                konamiIndex = 0;
            }
        } else {
            konamiIndex = 0;
        }
    });
}

// Show a hint when the Konami code is entered
function revealHint() {
    const modal = document.createElement('div');
    modal.classList.add('hint-modal');
    
    modal.innerHTML = `
        <div class="hint-content">
            <h3><i class="fas fa-lightbulb"></i> SQL Injection Hint</h3>
            <p>Try using <code>' OR '1'='1</code> in the login form!</p>
            <button class="close-hint">Got it!</button>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Add styles for the hint modal
    const style = document.createElement('style');
    style.textContent = `
        .hint-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            animation: fade-in 0.3s ease;
        }
        
        .hint-content {
            background-color: var(--primary-color);
            border: 2px solid var(--accent-color);
            border-radius: 8px;
            padding: 2rem;
            max-width: 500px;
            text-align: center;
            box-shadow: 0 0 30px var(--accent-glow);
        }
        
        .hint-content h3 {
            margin-bottom: 1rem;
            color: var(--accent-color);
        }
        
        .hint-content code {
            background-color: rgba(0, 0, 0, 0.3);
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-family: monospace;
        }
        
        .close-hint {
            margin-top: 1.5rem;
            padding: 0.5rem 1rem;
            background-color: var(--accent-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .close-hint:hover {
            background-color: #6366f1;
            box-shadow: 0 0 15px var(--accent-glow);
        }
        
        @keyframes fade-in {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    `;
    document.head.appendChild(style);
    
    // Close the hint modal when the button is clicked
    const closeButton = modal.querySelector('.close-hint');
    closeButton.addEventListener('click', function() {
        document.body.removeChild(modal);
    });
} 