from flask import Flask, request, render_template, redirect, session, url_for
import sqlite3
import os
import random

app = Flask(__name__)
app.secret_key = "super_secret_key_for_ctf_challenge"  # In a real app, this would be more secure

# Initialize the database
def init_db():
    conn = sqlite3.connect('challenge.db')
    cursor = conn.cursor()
    
    # Create users table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT NOT NULL,
        password TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0
    )
    ''')
    
    # Create a table to store the secret flag
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS secrets (
        id INTEGER PRIMARY KEY,
        secret_name TEXT NOT NULL,
        secret_value TEXT NOT NULL
    )
    ''')
    
    # Create admin user and insert flag if they don't exist
    cursor.execute("SELECT * FROM users WHERE username = 'admin'")
    if not cursor.fetchone():
        cursor.execute("INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)", 
                      ('admin', 'super_complex_password_' + str(random.randint(10000, 99999)), 1))
    
    # Insert flag if it doesn't exist
    cursor.execute("SELECT * FROM secrets WHERE secret_name = 'flag'")
    if not cursor.fetchone():
        cursor.execute("INSERT INTO secrets (secret_name, secret_value) VALUES (?, ?)", 
                      ('flag', 'CTF{SQL_1nj3ct10n_m4st3r_2023}'))
    
    conn.commit()
    conn.close()

# Initialize DB when the app starts
init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # VULNERABLE: SQL Injection vulnerability 
        # The correct way would be to use parameterized queries
        conn = sqlite3.connect('challenge.db')
        cursor = conn.cursor()
        query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
        
        try:
            cursor.execute(query)
            user = cursor.fetchone()
            
            if user:
                session['logged_in'] = True
                session['username'] = username
                session['is_admin'] = user[3]  # The is_admin field
                return redirect(url_for('dashboard'))
            else:
                error = 'Invalid credentials. Please try again.'
        except sqlite3.Error as e:
            error = f"Database error: {e}"
        finally:
            conn.close()
            
    return render_template('login.html', error=error)

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    # Only show the admin panel link if the user is an admin
    is_admin = session.get('is_admin', 0)
    return render_template('dashboard.html', username=session.get('username'), is_admin=is_admin)

@app.route('/admin')
def admin():
    if not session.get('logged_in') or not session.get('is_admin'):
        return redirect(url_for('login'))
    
    conn = sqlite3.connect('challenge.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM secrets")
    secrets = cursor.fetchall()
    conn.close()
    
    return render_template('admin.html', secrets=secrets)

@app.route('/search', methods=['GET', 'POST'])
def search():
    results = []
    search_term = ""
    
    if request.method == 'POST':
        search_term = request.form['search_term']
        
        # Another SQL Injection vulnerability
        conn = sqlite3.connect('challenge.db')
        cursor = conn.cursor()
        query = f"SELECT username FROM users WHERE username LIKE '%{search_term}%'"
        
        try:
            cursor.execute(query)
            results = cursor.fetchall()
        except sqlite3.Error as e:
            results = [("Error:", str(e))]
        finally:
            conn.close()
            
    return render_template('search.html', results=results, search_term=search_term)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True) 