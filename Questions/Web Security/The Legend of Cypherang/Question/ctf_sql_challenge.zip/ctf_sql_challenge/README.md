# SQL Injection CTF Challenge

A web-based Capture The Flag (CTF) challenge focused on SQL injection vulnerabilities.

## Challenge Description

The "CyberSec Institute" has just launched its new online portal, which claims to be highly secure and protected against various attacks. However, the developers may have overlooked some critical security vulnerabilities. Your mission is to find and exploit these vulnerabilities to gain access to sensitive information.

**Objective**: Find the flag hidden within the system by exploiting SQL injection vulnerabilities.

**Difficulty**: Beginner to Intermediate

## Setup Instructions

### Prerequisites
- Python 3.6+
- Flask

### Installation

1. Clone or download this repository to your local machine

2. Install the required Python packages:
```
pip install flask
```

3. Run the application:
```
python app.py
```

4. Open your web browser and navigate to:
```
http://localhost:5000
```

## Hints for Players

1. Look at the login page carefully - examine how the form is processed.
2. Search for hidden comments in the page source.
3. The administrator's panel might contain sensitive information.
4. Try looking for a way to bypass the login authentication.
5. The user search functionality might also be vulnerable.

## Solution (For CTF Organizers)

<details>
<summary>Click to reveal solution</summary>

### Login Bypass Solution

The login page is vulnerable to SQL injection. To bypass authentication:

1. Username: `admin' --`
2. Password: (anything)

or

1. Username: `' OR '1'='1` 
2. Password: `' OR '1'='1`

### Finding the Flag

After logging in as admin, you'll have access to the Admin Panel where the flag is displayed:

Flag: `CTF{SQL_1nj3ct10n_m4st3r_2023}`

### Alternative Route (Search Page)

The search functionality is also vulnerable. You can use:

```
' UNION SELECT secret_value FROM secrets --
```

This will return the flag in the search results.

</details>

## License

This project is meant for educational purposes only. Use it responsibly and only in environments where you have permission to test for security vulnerabilities.

## Credits

Created for educational purposes as a SQL injection demonstration tool. Not for use in production environments. 